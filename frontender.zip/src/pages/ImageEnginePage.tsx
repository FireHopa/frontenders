import React, { useState } from 'react';
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type ImageResult = {
  posicao: number;
  motor: string;
  nota: number;
  justificativa: string;
  url: string;
};

export default function ImageEnginePage() {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [statusText, setStatusText] = useState("");
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<ImageResult[] | null>(null);
  const [improvedPrompt, setImprovedPrompt] = useState("");

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setProgress(0);
    setResults(null);
    setStatusText("Iniciando a conexão segura...");

    // 1. Pegamos o token do Zustand silenciosamente
    const authStorageStr = localStorage.getItem("auth-store");
    let token = "";
    if (authStorageStr) {
      try {
        const authData = JSON.parse(authStorageStr);
        token = authData?.state?.token || "";
      } catch (e) {
        console.error("Erro ao ler token", e);
      }
    }

    try {
      // 2. Usamos fetch com o Header de Autenticação em vez do EventSource
      const response = await fetch(`http://localhost:8000/api/image-engine/stream?prompt=${encodeURIComponent(prompt)}`, {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Accept": "text/event-stream",
        },
      });

      if (!response.ok) {
        if (response.status === 401) {
          setStatusText("Erro: Não autorizado (Sessão expirada). Por favor, faça login novamente.");
        } else {
          setStatusText(`Erro HTTP: ${response.status}`);
        }
        setIsGenerating(false);
        return;
      }

      // 3. Lemos o Stream de dados (SSE) pedaço por pedaço
      const reader = response.body?.getReader();
      const decoder = new TextDecoder("utf-8");
      let buffer = "";

      if (!reader) throw new Error("Falha ao inicializar o leitor de stream");

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const parts = buffer.split("\n\n");
        buffer = parts.pop() || ""; // Mantém o que sobrou para o próximo ciclo

        for (const part of parts) {
          if (part.startsWith("data: ")) {
            try {
              const dataStr = part.substring(6);
              const data = JSON.parse(dataStr);

              if (data.error) {
                setStatusText("Erro: " + data.error);
                setIsGenerating(false);
                return;
              }

              if (data.status) setStatusText(data.status);
              if (data.progress) setProgress(data.progress);

              if (data.final_ranking) {
                setResults(data.final_ranking);
                setImprovedPrompt(data.improved_prompt);
                setIsGenerating(false);
              }
            } catch (e) {
              console.error("Erro ao processar JSON do stream", e);
            }
          }
        }
      }
    } catch (error) {
      console.error(error);
      setStatusText("Conexão perdida com o servidor.");
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8 animate-in fade-in">
      <div>
        <h1 className="text-3xl font-bold">Motor de Imagem</h1>
        <p className="text-muted-foreground">Envie seu prompt e deixe a IA competir pela melhor geração.</p>
      </div>

      <Card className="p-6">
        <div className="flex gap-4">
          <Input 
            placeholder="Ex: Um cachorro astronauta em marte tomando um café iluminado por neon..." 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            disabled={isGenerating}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleGenerate();
            }}
          />
          <Button onClick={handleGenerate} disabled={isGenerating || !prompt}>
            {isGenerating ? "Gerando..." : "Gerar"}
          </Button>
        </div>

        {/* Barra de Progresso Nativa com Tailwind */}
        {isGenerating && (
          <div className="mt-6 space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span className="font-medium animate-pulse">{statusText}</span>
              <span>{progress}%</span>
            </div>
            <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-600 transition-all duration-500 ease-out" 
                style={{ width: `${progress}%` }} 
              />
            </div>
          </div>
        )}
      </Card>

      {/* Resultados do Ranking */}
      {results && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
          <div className="bg-secondary p-4 rounded-lg">
            <h3 className="font-bold text-sm text-muted-foreground mb-1">Prompt Enriquecido pelo GPT:</h3>
            <p className="italic">{improvedPrompt}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {results.map((res, index) => (
              <Card key={index} className={`overflow-hidden border-2 transition-all hover:scale-105 ${index === 0 ? 'border-yellow-500 shadow-yellow-500/20 shadow-lg' : 'border-transparent'}`}>
                <div className="aspect-square bg-muted relative">
                  <img src={res.url} alt={res.motor} className="object-cover w-full h-full" />
                  <div className="absolute top-2 left-2 bg-black/80 text-white px-3 py-1 rounded-full text-sm font-bold border border-white/20">
                    #{res.posicao} Lugar
                  </div>
                  <div className="absolute top-2 right-2 bg-blue-600/90 text-white px-2 py-1 rounded-md text-sm font-bold backdrop-blur-sm">
                    Nota: {res.nota}
                  </div>
                </div>
                <div className="p-4 bg-card">
                  <h3 className="font-bold text-lg">{res.motor}</h3>
                  <p className="text-sm text-muted-foreground mt-2">{res.justificativa}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}