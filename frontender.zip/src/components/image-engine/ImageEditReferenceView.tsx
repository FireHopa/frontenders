import React, { useEffect, useMemo, useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  ArrowLeft,
  Brush,
  Check,
  Facebook,
  Gauge,
  Globe,
  Image as ImageIcon,
  Instagram,
  LayoutTemplate,
  Linkedin,
  Loader2,
  MessageCircle,
  Monitor,
  Palette,
  Rocket,
  ScanSearch,
  Smartphone,
  Sparkles,
  Square,
  Target,
  Upload,
  Wand2,
  Youtube,
} from "lucide-react";
import { API_BASE_URL } from "@/constants/app";

type ImageResult = {
  engine_id: string;
  motor: string;
  url: string;
};

type FormatOption = {
  value: string;
  label: string;
  hint: string;
  icon: React.ReactNode;
};

type PaletteOption = {
  value: string;
  label: string;
  colors: string[];
};

type DestinationOption = {
  value: string;
  label: string;
  hint: string;
  icon: React.ReactNode;
  recommendedFormat: string;
  recommendedQuality: string;
};

const FORMAT_OPTIONS: FormatOption[] = [
  {
    value: "quadrado_1_1",
    label: "Quadrado 1:1",
    hint: "Ideal para feed estático e criativos versáteis.",
    icon: <Square className="w-5 h-5" />,
  },
  {
    value: "vertical_9_16",
    label: "Vertical 9:16",
    hint: "Stories, Reels, Shorts e Status.",
    icon: <Smartphone className="w-5 h-5" />,
  },
  {
    value: "horizontal_16_9",
    label: "Horizontal 16:9",
    hint: "Thumbnails, banners e áreas amplas.",
    icon: <Monitor className="w-5 h-5" />,
  },
];

const DESTINATION_OPTIONS: DestinationOption[] = [
  {
    value: "Instagram Feed",
    label: "Instagram Feed",
    hint: "Post estático de alta atenção.",
    icon: <Instagram className="w-5 h-5" />,
    recommendedFormat: "quadrado_1_1",
    recommendedQuality: "media",
  },
  {
    value: "Instagram Stories",
    label: "Instagram Stories",
    hint: "Tela cheia com apelo rápido.",
    icon: <Instagram className="w-5 h-5" />,
    recommendedFormat: "vertical_9_16",
    recommendedQuality: "media",
  },
  {
    value: "Instagram Reels",
    label: "Instagram Reels",
    hint: "Capa e criativo vertical.",
    icon: <Instagram className="w-5 h-5" />,
    recommendedFormat: "vertical_9_16",
    recommendedQuality: "media",
  },
  {
    value: "Facebook Feed",
    label: "Facebook Feed",
    hint: "Criativo para campanhas e posts.",
    icon: <Facebook className="w-5 h-5" />,
    recommendedFormat: "quadrado_1_1",
    recommendedQuality: "media",
  },
  {
    value: "LinkedIn Post",
    label: "LinkedIn Post",
    hint: "Peças mais limpas e profissionais.",
    icon: <Linkedin className="w-5 h-5" />,
    recommendedFormat: "quadrado_1_1",
    recommendedQuality: "media",
  },
  {
    value: "YouTube Thumbnail",
    label: "YouTube Thumbnail",
    hint: "Máximo destaque e leitura rápida.",
    icon: <Youtube className="w-5 h-5" />,
    recommendedFormat: "horizontal_16_9",
    recommendedQuality: "alta",
  },
  {
    value: "WhatsApp Status",
    label: "WhatsApp Status",
    hint: "Visual direto e vertical.",
    icon: <MessageCircle className="w-5 h-5" />,
    recommendedFormat: "vertical_9_16",
    recommendedQuality: "media",
  },
  {
    value: "Landing Page / Site",
    label: "Landing Page / Site",
    hint: "Hero banners e áreas principais.",
    icon: <Globe className="w-5 h-5" />,
    recommendedFormat: "horizontal_16_9",
    recommendedQuality: "alta",
  },
];

const PALETTE_OPTIONS: PaletteOption[] = [
  { value: "google", label: "Google Tech", colors: ["#4285F4", "#EA4335", "#FBBC05", "#34A853"] },
  { value: "premium_blue", label: "Azul Premium", colors: ["#0F172A", "#1D4ED8", "#60A5FA", "#E2E8F0"] },
  { value: "dark_luxury", label: "Dark Luxury", colors: ["#0B0B0B", "#1F2937", "#D4AF37", "#F9FAFB"] },
  { value: "clean_neutral", label: "Clean Neutral", colors: ["#111827", "#6B7280", "#F3F4F6", "#FFFFFF"] },
  { value: "custom", label: "Personalizada", colors: [] },
];

const QUALITY_OPTIONS = [
  {
    value: "baixa",
    label: "Rascunho",
    hint: "Testes rápidos e validação de direção.",
    icon: <Gauge className="w-5 h-5" />,
  },
  {
    value: "media",
    label: "Equilibrada",
    hint: "Boa definição com custo-benefício.",
    icon: <Target className="w-5 h-5" />,
  },
  {
    value: "alta",
    label: "Premium",
    hint: "Maior nível de detalhe e refinamento.",
    icon: <Sparkles className="w-5 h-5" />,
  },
];

function getRecommendedQuality(destination: string): string {
  const found = DESTINATION_OPTIONS.find((item) => item.value === destination);
  return found?.recommendedQuality || "media";
}

function getRecommendedFormat(destination: string): string {
  const found = DESTINATION_OPTIONS.find((item) => item.value === destination);
  return found?.recommendedFormat || "quadrado_1_1";
}

function getAspectClass(formato: string) {
  if (formato === "vertical_9_16") return "aspect-[9/16]";
  if (formato === "horizontal_16_9") return "aspect-video";
  return "aspect-square";
}

function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

function getAuthToken() {
  try {
    return JSON.parse(localStorage.getItem("auth-store") || "{}")?.state?.token || "";
  } catch {
    return "";
  }
}

type Props = {
  onBack: () => void;
};

export default function ImageEditReferenceView({ onBack }: Props) {
  const [formato, setFormato] = useState<string>("quadrado_1_1");
  const [qualidade, setQualidade] = useState<string>("media");
  const [ondePostar, setOndePostar] = useState<string>("Instagram Feed");
  const [paletaSelecionada, setPaletaSelecionada] = useState<string>("google");
  const [paletaCustom, setPaletaCustom] = useState<string>("");
  const [headline, setHeadline] = useState<string>("");
  const [subheadline, setSubheadline] = useState<string>("");
  const [instrucoesEdicao, setInstrucoesEdicao] = useState<string>("");
  const [referenceFile, setReferenceFile] = useState<File | null>(null);
  const [referencePreview, setReferencePreview] = useState<string>("");

  const [isGenerating, setIsGenerating] = useState(false);
  const [statusText, setStatusText] = useState("");
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<ImageResult[]>([]);
  const [improvedPrompt, setImprovedPrompt] = useState("");
  const [finalPrompt, setFinalPrompt] = useState("");

  const recommendedQuality = useMemo(() => getRecommendedQuality(ondePostar), [ondePostar]);
  const recommendedFormat = useMemo(() => getRecommendedFormat(ondePostar), [ondePostar]);

  const currentDestination = useMemo(
    () => DESTINATION_OPTIONS.find((item) => item.value === ondePostar),
    [ondePostar]
  );

  const currentFormat = useMemo(
    () => FORMAT_OPTIONS.find((item) => item.value === formato),
    [formato]
  );

  const currentQuality = useMemo(
    () => QUALITY_OPTIONS.find((item) => item.value === qualidade),
    [qualidade]
  );

  const paletteValue = useMemo(() => {
    if (paletaSelecionada === "custom") return paletaCustom.trim();
    const selected = PALETTE_OPTIONS.find((option) => option.value === paletaSelecionada);
    return selected ? `${selected.label}: ${selected.colors.join(", ")}` : "";
  }, [paletaSelecionada, paletaCustom]);

  const selectedPalette = useMemo(
    () => PALETTE_OPTIONS.find((item) => item.value === paletaSelecionada),
    [paletaSelecionada]
  );

  useEffect(() => {
    if (!referenceFile) {
      setReferencePreview("");
      return;
    }

    const url = URL.createObjectURL(referenceFile);
    setReferencePreview(url);

    return () => {
      URL.revokeObjectURL(url);
    };
  }, [referenceFile]);

  const handleApplyRecommendations = () => {
    setFormato(recommendedFormat);
    setQualidade(recommendedQuality);
  };

  const handleSelectFile = (file?: File | null) => {
    if (!file) return;

    const validTypes = ["image/png", "image/jpeg", "image/jpg", "image/webp"];
    if (!validTypes.includes(file.type)) {
      setStatusText("⚠ Envie uma imagem PNG, JPG, JPEG ou WEBP.");
      return;
    }

    setReferenceFile(file);
    setStatusText("");
  };

  const handleGenerate = async () => {
    if (!referenceFile) {
      setStatusText("⚠ Envie uma imagem de referência antes de continuar.");
      return;
    }

    if (!instrucoesEdicao.trim()) {
      setStatusText("⚠ Escreva o que a IA deve editar na imagem.");
      return;
    }

    if (paletaSelecionada === "custom" && !paletaCustom.trim()) {
      setStatusText("⚠ Descreva sua paleta personalizada.");
      return;
    }

    setIsGenerating(true);
    setProgress(0);
    setResults([]);
    setImprovedPrompt("");
    setFinalPrompt("");
    setStatusText("Preparando a referência e refinando o prompt de edição...");

    const token = getAuthToken();
    const formData = new FormData();
    formData.append("reference_image", referenceFile);
    formData.append("formato", formato);
    formData.append("qualidade", qualidade);
    formData.append("onde_postar", ondePostar);
    formData.append("paleta_cores", paletteValue);
    formData.append("headline", headline);
    formData.append("subheadline", subheadline);
    formData.append("instrucoes_edicao", instrucoesEdicao);

    try {
      const response = await fetch(`${API_BASE_URL}/api/image-engine/edit/stream`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "text/event-stream",
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(response.status === 401 ? "Sessão expirada." : `Erro ${response.status}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder("utf-8");
      let buffer = "";

      if (!reader) throw new Error("Falha ao inicializar o leitor");

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const parts = buffer.split("\n\n");
        buffer = parts.pop() || "";

        for (const part of parts) {
          if (!part.startsWith("data: ")) continue;

          try {
            const data = JSON.parse(part.substring(6));

            if (data.error) throw new Error(data.error);
            if (data.status) setStatusText(data.status);
            if (typeof data.progress === "number") setProgress(data.progress);
            if (data.improved_prompt) setImprovedPrompt(data.improved_prompt);
            if (data.final_prompt) setFinalPrompt(data.final_prompt);

            if (data.partial_result?.url) {
              setResults((current) =>
                current.some((item) => item.engine_id === data.partial_result.engine_id)
                  ? current
                  : [...current, data.partial_result]
              );
            }

            if (Array.isArray(data.final_results)) {
              setResults(data.final_results);
              setIsGenerating(false);
            }
          } catch (e) {
            console.error("Erro no SSE", e);
          }
        }
      }

      setIsGenerating(false);
    } catch (error: any) {
      setStatusText(`Erro: ${error.message || "Conexão perdida."}`);
      setIsGenerating(false);
    }
  };

  return (
    <div className="mx-auto max-w-7xl p-4 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-8">
        <div className="rounded-3xl border border-white/10 bg-[linear-gradient(135deg,rgba(15,23,42,0.96)_0%,rgba(2,6,23,0.98)_60%,rgba(7,12,22,1)_100%)] shadow-[0_20px_60px_rgba(0,0,0,0.35)] overflow-hidden">
          <div className="p-6 md:p-8 flex flex-col gap-6">
            <div className="flex flex-col gap-4">
              <Button
                type="button"
                variant="outline"
                className="w-fit rounded-xl h-10 px-4 border-white/10 bg-white/[0.04] text-slate-200 hover:bg-white/[0.08]"
                onClick={onBack}
                disabled={isGenerating}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>

              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-5">
                <div className="space-y-3">
                  <div className="inline-flex items-center gap-2 rounded-full border border-purple-400/20 bg-purple-500/10 px-3 py-1 text-sm font-medium text-purple-300">
                    <LayoutTemplate className="w-4 h-4" />
                    Edição guiada por referência
                  </div>

                  <div className="space-y-2">
                    <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-white">
                      Editar imagem a partir de referência
                    </h1>
                    <p className="text-base md:text-lg text-slate-300 max-w-3xl">
                      Envie uma imagem base, descreva as alterações e deixe a IA refinar o prompt antes de gerar a nova versão editada.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 min-w-full lg:min-w-[420px]">
                  <div className="rounded-2xl border border-white/10 bg-white/[0.04] backdrop-blur-sm p-4">
                    <div className="text-xs uppercase tracking-wide text-slate-400 mb-1">
                      Destino
                    </div>
                    <div className="flex items-center gap-2 font-semibold text-white">
                      {currentDestination?.icon}
                      <span>{ondePostar}</span>
                    </div>
                  </div>

                  <div className="rounded-2xl border border-white/10 bg-white/[0.04] backdrop-blur-sm p-4">
                    <div className="text-xs uppercase tracking-wide text-slate-400 mb-1">
                      Formato
                    </div>
                    <div className="font-semibold text-white">{currentFormat?.label}</div>
                  </div>

                  <div className="rounded-2xl border border-white/10 bg-white/[0.04] backdrop-blur-sm p-4">
                    <div className="text-xs uppercase tracking-wide text-slate-400 mb-1">
                      Qualidade
                    </div>
                    <div className="font-semibold text-white">{currentQuality?.label}</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-col lg:flex-row gap-3 lg:items-center lg:justify-between rounded-2xl border border-white/10 bg-white/[0.04] p-4">
              <div className="flex flex-col md:flex-row md:items-center gap-3 text-sm">
                <div className="inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-500/10 px-3 py-1 text-emerald-300">
                  <ScanSearch className="w-4 h-4" />
                  Recomendação automática ativa
                </div>

                <div className="text-slate-300">
                  Para <span className="font-medium text-white">{ondePostar}</span>, o ideal é{" "}
                  <span className="font-medium text-white">
                    {FORMAT_OPTIONS.find((f) => f.value === recommendedFormat)?.label}
                  </span>{" "}
                  e{" "}
                  <span className="font-medium text-white">
                    {QUALITY_OPTIONS.find((q) => q.value === recommendedQuality)?.label}
                  </span>.
                </div>
              </div>

              <Button
                type="button"
                variant="outline"
                className="rounded-xl h-11 px-4 border-blue-400/20 bg-blue-500/10 text-blue-300 hover:bg-blue-500/15 hover:text-blue-200"
                onClick={handleApplyRecommendations}
                disabled={isGenerating}
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Aplicar padrão ideal
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-12 max-w-5xl mx-auto w-full">
        <div className="space-y-6 w-full">
          <Card className="border-white/10 bg-[linear-gradient(180deg,rgba(7,12,22,0.96)_0%,rgba(6,10,18,0.98)_100%)] shadow-[0_10px_40px_rgba(0,0,0,0.22)]">
            <CardHeader className="pb-4">
              <CardTitle className="text-xl md:text-2xl font-semibold tracking-tight flex items-center gap-2 text-white">
                <Upload className="w-5 h-5 text-blue-400" />
                1. Imagem de referência
              </CardTitle>
              <CardDescription className="text-slate-400">
                Envie a imagem base que a IA vai usar como ponto de partida para a edição.
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-5">
              <label
                htmlFor="reference-image-upload"
                className="group flex cursor-pointer flex-col items-center justify-center rounded-3xl border border-dashed border-white/15 bg-white/[0.03] p-6 text-center transition hover:border-blue-400/40 hover:bg-white/[0.05]"
              >
                {referencePreview ? (
                  <div className="w-full space-y-4">
                    <div className="overflow-hidden rounded-2xl border border-white/10 bg-black/20">
                      <img
                        src={referencePreview}
                        alt="Imagem de referência"
                        className="max-h-[420px] w-full object-contain bg-slate-950"
                      />
                    </div>
                    <div className="text-sm text-slate-300">
                      <span className="font-medium text-white">{referenceFile?.name}</span>
                    </div>
                    <div className="text-xs text-slate-400">
                      Clique para trocar a imagem de referência.
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl border border-blue-400/10 bg-blue-500/10">
                      <Upload className="h-8 w-8 text-blue-300" />
                    </div>
                    <div className="text-lg font-semibold text-white">
                      Clique para enviar sua imagem de referência
                    </div>
                    <div className="mt-2 text-sm text-slate-400 max-w-xl">
                      Aceita PNG, JPG, JPEG e WEBP. A IA vai preservar a base visual e aplicar as alterações que você escrever.
                    </div>
                  </>
                )}
                <input
                  id="reference-image-upload"
                  type="file"
                  accept="image/png,image/jpeg,image/jpg,image/webp"
                  className="hidden"
                  disabled={isGenerating}
                  onChange={(e) => handleSelectFile(e.target.files?.[0] || null)}
                />
              </label>
            </CardContent>
          </Card>

          <Card className="border-white/10 bg-[linear-gradient(180deg,rgba(7,12,22,0.96)_0%,rgba(6,10,18,0.98)_100%)] shadow-[0_10px_40px_rgba(0,0,0,0.22)]">
            <CardHeader className="pb-4">
              <CardTitle className="text-xl md:text-2xl font-semibold tracking-tight flex items-center gap-2 text-white">
                <Rocket className="w-5 h-5 text-blue-400" />
                2. Canal e configuração da mídia
              </CardTitle>
              <CardDescription className="text-slate-400">
                Escolha onde a peça será publicada para orientar a edição com foco em resultado real.
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-8">
              <div className="space-y-3">
                <label className="text-sm font-semibold text-white">Onde vai ser postado?</label>

                <div className="flex flex-wrap gap-3">
                  {DESTINATION_OPTIONS.map((option) => {
                    const isSelected = ondePostar === option.value;

                    return (
                      <button
                        key={option.value}
                        type="button"
                        disabled={isGenerating}
                        onClick={() => setOndePostar(option.value)}
                        className={cn(
                          "flex items-center gap-2.5 px-4 py-2.5 rounded-xl border text-sm font-medium transition-all duration-200",
                          isSelected
                            ? "border-blue-500 bg-blue-500/15 text-blue-200 shadow-[0_0_0_1px_rgba(59,130,246,0.2)]"
                            : "border-white/10 bg-white/[0.03] text-slate-300 hover:border-blue-400/30 hover:bg-white/[0.05]"
                        )}
                      >
                        <div className={cn("shrink-0", isSelected ? "text-blue-400" : "text-slate-400")}>
                          {option.icon}
                        </div>
                        {option.label}
                        {isSelected && <Check className="w-3.5 h-3.5 ml-1 text-blue-400 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-8">
                <div className="space-y-3">
                  <label className="text-sm font-semibold flex items-center justify-between text-white">
                    Formato de saída
                    <span className="text-xs font-normal text-slate-400">
                      Recomendado: {FORMAT_OPTIONS.find((f) => f.value === recommendedFormat)?.label}
                    </span>
                  </label>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {FORMAT_OPTIONS.map((option) => (
                      <button
                        key={option.value}
                        type="button"
                        disabled={isGenerating}
                        onClick={() => setFormato(option.value)}
                        className={cn(
                          "relative flex flex-col items-center justify-center p-4 rounded-2xl border transition-all duration-200",
                          formato === option.value
                            ? "border-blue-500 bg-blue-500/10 shadow-[0_0_0_1px_rgba(59,130,246,0.15)]"
                            : "border-white/10 bg-white/[0.03] hover:border-blue-400/30"
                        )}
                      >
                        <div className={cn("mb-2", formato === option.value ? "text-blue-300" : "text-slate-400")}>
                          {option.icon}
                        </div>
                        <span className="font-medium text-sm text-white">{option.label}</span>
                        <span className="text-xs text-slate-400 mt-1 text-center">{option.hint}</span>

                        {recommendedFormat === option.value && (
                          <div className="absolute -top-2.5 right-2 px-2 py-0.5 rounded-full bg-blue-500 text-[10px] font-bold text-white shadow-sm">
                            IDEAL
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-sm font-semibold flex items-center justify-between text-white">
                    Qualidade da renderização
                    <span className="text-xs font-normal text-slate-400">
                      Recomendado: {QUALITY_OPTIONS.find((q) => q.value === recommendedQuality)?.label}
                    </span>
                  </label>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {QUALITY_OPTIONS.map((option) => (
                      <button
                        key={option.value}
                        type="button"
                        disabled={isGenerating}
                        onClick={() => setQualidade(option.value)}
                        className={cn(
                          "relative flex items-center gap-3 p-4 rounded-2xl border transition-all duration-200 text-left",
                          qualidade === option.value
                            ? "border-blue-500 bg-blue-500/10 shadow-[0_0_0_1px_rgba(59,130,246,0.15)]"
                            : "border-white/10 bg-white/[0.03] hover:border-blue-400/30"
                        )}
                      >
                        <div className={cn("shrink-0", qualidade === option.value ? "text-blue-300" : "text-slate-400")}>
                          {option.icon}
                        </div>
                        <div>
                          <span className="block font-medium text-sm text-white">{option.label}</span>
                          <span className="block text-xs text-slate-400 mt-0.5">{option.hint}</span>
                        </div>

                        {recommendedQuality === option.value && (
                          <div className="absolute -top-2.5 right-2 px-2 py-0.5 rounded-full bg-blue-500 text-[10px] font-bold text-white shadow-sm">
                            IDEAL
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/10 bg-[linear-gradient(180deg,rgba(7,12,22,0.96)_0%,rgba(6,10,18,0.98)_100%)] shadow-[0_10px_40px_rgba(0,0,0,0.22)]">
            <CardHeader className="pb-4">
              <CardTitle className="text-xl md:text-2xl font-semibold tracking-tight flex items-center gap-2 text-white">
                <Brush className="w-5 h-5 text-blue-400" />
                3. Direção da edição
              </CardTitle>
              <CardDescription className="text-slate-400">
                Diga o que deve permanecer, o que deve mudar e como a nova imagem deve ser percebida.
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-6">
              <div className="space-y-3">
                <label className="text-sm font-semibold flex items-center gap-2 text-white">
                  <Palette className="w-4 h-4 text-slate-400" />
                  Paleta de cores
                </label>

                <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
                  {PALETTE_OPTIONS.map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      disabled={isGenerating}
                      onClick={() => setPaletaSelecionada(option.value)}
                      className={cn(
                        "flex flex-col justify-between p-3 rounded-2xl border transition-all",
                        paletaSelecionada === option.value
                          ? "border-blue-500 bg-blue-500/10 shadow-[0_0_0_1px_rgba(59,130,246,0.15)]"
                          : "border-white/10 bg-white/[0.03] hover:border-blue-400/30"
                      )}
                    >
                      <span className="font-medium text-xs truncate w-full text-left mb-3 text-white">
                        {option.label}
                      </span>

                      <div className="flex w-full overflow-hidden rounded-md h-4 ring-1 ring-black/5 dark:ring-white/10">
                        {option.colors.length > 0 ? (
                          option.colors.map((c) => (
                            <div key={c} style={{ backgroundColor: c }} className="h-full flex-1" />
                          ))
                        ) : (
                          <div className="w-full h-full bg-gradient-to-r from-slate-700 to-slate-500" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>

                {paletaSelecionada === "custom" && (
                  <div className="animate-in slide-in-from-top-2">
                    <Input
                      className="h-11 mt-2 border-white/10 bg-white/[0.03] text-white placeholder:text-slate-500"
                      placeholder="Ex: tons pastéis, neon, minimalista clean ou HEX (#FF0000, #111827)..."
                      value={paletaCustom}
                      onChange={(e) => setPaletaCustom(e.target.value)}
                      disabled={isGenerating}
                    />
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-white">Headline</label>
                  <Input
                    className="h-11 border-white/10 bg-white/[0.03] text-white placeholder:text-slate-500"
                    placeholder="Ex: Black Friday até 50% OFF"
                    value={headline}
                    onChange={(e) => setHeadline(e.target.value)}
                    disabled={isGenerating}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-white">Sub-headline</label>
                  <Input
                    className="h-11 border-white/10 bg-white/[0.03] text-white placeholder:text-slate-500"
                    placeholder="Ex: Compre agora com condição especial"
                    value={subheadline}
                    onChange={(e) => setSubheadline(e.target.value)}
                    disabled={isGenerating}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-white">Instruções de edição</label>
                <Textarea
                  className="min-h-[180px] resize-none text-base leading-relaxed border-white/10 bg-white/[0.03] text-white placeholder:text-slate-500"
                  placeholder="Ex: mantenha o produto principal, troque o fundo por um cenário premium, aumente o contraste, aplique iluminação de estúdio, preserve o enquadramento central e adicione espaço limpo para headline no topo..."
                  value={instrucoesEdicao}
                  onChange={(e) => setInstrucoesEdicao(e.target.value)}
                  disabled={isGenerating}
                />
                <p className="text-xs text-slate-400">
                  Seja claro sobre o que deve ser preservado e o que precisa mudar. A IA vai refinar seu pedido antes de editar a imagem.
                </p>
              </div>
            </CardContent>

            <CardFooter className="bg-white/[0.02] pt-6 flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between border-t border-white/10">
              <div className="text-sm text-slate-400">
                {selectedPalette?.label ? (
                  <span>
                    Paleta atual: <span className="font-medium text-white">{selectedPalette.label}</span>
                  </span>
                ) : null}
              </div>

              <Button
                size="lg"
                className="w-full sm:w-auto font-semibold gap-2 rounded-xl h-12 px-6 bg-blue-600 hover:bg-blue-500 text-white"
                onClick={handleGenerate}
                disabled={isGenerating || !referenceFile || !instrucoesEdicao.trim()}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Processando {progress}%
                  </>
                ) : (
                  <>
                    <ImageIcon className="w-5 h-5" />
                    Editar imagem
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div className="space-y-6 w-full">
          {(isGenerating || improvedPrompt || finalPrompt || statusText) && (
            <Card className="border-white/10 bg-[linear-gradient(180deg,rgba(7,12,22,0.96)_0%,rgba(6,10,18,0.98)_100%)] shadow-[0_10px_40px_rgba(0,0,0,0.22)]">
              <CardContent className="p-6 space-y-5">
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-semibold text-blue-300 flex items-center gap-2">
                      {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                      {statusText || (isGenerating ? "Editando imagem..." : "Pronto")}
                    </span>

                    <span className="font-mono text-slate-400">{progress}%</span>
                  </div>

                  <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
                    <div className="h-full bg-blue-500 transition-all duration-500 ease-out" style={{ width: `${progress}%` }} />
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-1">
                    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                      <div className="text-[10px] uppercase tracking-wide text-slate-500 mb-1">Canal</div>
                      <div className="text-sm font-medium text-white">{ondePostar}</div>
                    </div>

                    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                      <div className="text-[10px] uppercase tracking-wide text-slate-500 mb-1">Formato</div>
                      <div className="text-sm font-medium text-white">{currentFormat?.label}</div>
                    </div>

                    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                      <div className="text-[10px] uppercase tracking-wide text-slate-500 mb-1">Qualidade</div>
                      <div className="text-sm font-medium text-white">{currentQuality?.label}</div>
                    </div>
                  </div>
                </div>

                {improvedPrompt && (
                  <div className="space-y-2 animate-in fade-in">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">Prompt otimizado pela IA</h3>
                    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
                      <p className="text-sm text-slate-200 leading-relaxed italic">“{improvedPrompt}”</p>
                    </div>
                  </div>
                )}

                {finalPrompt && (
                  <details className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
                    <summary className="cursor-pointer text-sm font-medium flex items-center gap-2 text-white">
                      Ver prompt final enviado ao editor
                    </summary>
                    <p className="mt-3 text-xs text-slate-400 leading-relaxed whitespace-pre-wrap break-words">
                      {finalPrompt}
                    </p>
                  </details>
                )}
              </CardContent>
            </Card>
          )}

          <div className="space-y-4">
            {results.length > 0 ? (
              <div className="grid gap-6">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-xl flex items-center gap-2 text-white">
                    <Sparkles className="w-6 h-6 text-yellow-400" />
                    Edição concluída
                  </h3>

                  <div className="text-xs text-slate-400">Imagem original versus imagem editada</div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="overflow-hidden border-white/10 bg-slate-900 shadow-[0_10px_30px_rgba(0,0,0,0.22)] rounded-2xl">
                    <div className="p-3 text-xs uppercase tracking-wide text-slate-400 border-b border-white/10 bg-white/[0.02]">
                      Referência enviada
                    </div>
                    <div className={cn("relative overflow-hidden w-full bg-slate-950", getAspectClass(formato))}>
                      {referencePreview && (
                        <img
                          src={referencePreview}
                          alt="Referência"
                          className="absolute inset-0 h-full w-full object-contain"
                        />
                      )}
                    </div>
                  </Card>

                  {results.map((result) => (
                    <Card
                      key={result.engine_id}
                      className="overflow-hidden border-white/10 bg-slate-900 shadow-[0_10px_30px_rgba(0,0,0,0.22)] rounded-2xl"
                    >
                      <div className="p-3 text-xs uppercase tracking-wide text-slate-400 border-b border-white/10 bg-white/[0.02]">
                        {result.motor}
                      </div>
                      <div className={cn("relative overflow-hidden w-full bg-slate-950", getAspectClass(formato))}>
                        <img
                          src={result.url}
                          alt={result.motor}
                          className="absolute inset-0 h-full w-full object-contain"
                          loading="lazy"
                        />
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            ) : isGenerating ? (
              <div className="space-y-4">
                <h3 className="font-semibold text-lg text-slate-300">Editando prévia...</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[1, 2].map((i) => (
                    <Card
                      key={i}
                      className="overflow-hidden border-white/10 bg-[linear-gradient(180deg,rgba(7,12,22,0.96)_0%,rgba(6,10,18,0.98)_100%)] opacity-80 shadow-sm"
                    >
                      <div className={cn("bg-slate-800 animate-pulse w-full", getAspectClass(formato))} />
                    </Card>
                  ))}
                </div>
              </div>
            ) : (
              <div className="h-full min-h-[360px] flex flex-col items-center justify-center text-center p-8 border border-white/10 rounded-3xl bg-[linear-gradient(180deg,rgba(7,12,22,0.96)_0%,rgba(6,10,18,0.98)_100%)]">
                <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-500/10 mb-4 border border-blue-400/10">
                  <ImageIcon className="w-8 h-8 text-blue-300" />
                </div>

                <h3 className="font-semibold text-lg mb-2 text-white">Nenhuma edição gerada ainda</h3>
                <p className="text-sm text-slate-400 max-w-[360px] leading-relaxed">
                  Envie a referência, escreva as alterações desejadas e clique em <span className="font-medium text-white">Editar imagem</span> para visualizar a nova versão.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
